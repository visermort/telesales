<?php $__env->startSection('content'); ?>

                <div class="panel-heading"><?php echo e($title); ?></div>
                <div class="panel-body">
                    <div class="alert <?php if($status == true): ?> alert-success <?php else: ?> alert-danger <?php endif; ?>">
                        <?php echo e($message); ?>

                    </div>
                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <a class="btn btn-primary" href="<?php echo e(action('HomeController@index')); ?>">Продолжить</a>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>