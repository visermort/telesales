<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить пользователя
        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('Admin\UsersController@update', $user->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                <label for="first_name">Имя </label>
                <input name="first_name" id="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" >

                <?php if($errors->has('first_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                <label for="last_name">Фамилия </label>
                <input name="last_name" id="last_name" class="form-control" value="<?php echo e($user->last_name); ?>">

                <?php if($errors->has('last_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email">Email </label>
                <input name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>">

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('Admin\UsersController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>