<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить заказ
        № <?php echo e($order->order_id); ?> от <?php echo e($order->user->first_name); ?> <?php echo e($order->user->last_name); ?> <?php echo e($order->user->email); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('OrderController@update', $order->order_id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('item_type') ? ' has-error' : ''); ?>">
                <label for="item_type">Тип заказа</label>
                <select id="item_type" class="form-control" name="item_type" >
                    <option value="">-- Выберите тип --</option>
                    <?php $__currentLoopData = config('telesales.itemTypes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $itemType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"  <?php if($key == $order->item_type): ?> selected <?php endif; ?> ><?php echo e($itemType); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('item_type')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('item_type')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group<?php echo e($errors->has('item_id') ? ' has-error' : ''); ?>">
                <label for="item_id">Заказ</label>
                <select id="item_id" class="form-control" name="item_id" data-value="<?php echo e($order->item_id); ?>" >
                    <option value="">-- Выберите заказ --</option>

                </select>
                <?php if($errors->has('item_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('item_id')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class=" form-group<?php echo e($errors->has('order_state_id') ? ' has-error' : ''); ?>">
                <label for="order_state_id">Статус заказа</label>
                <select id="order_state_id" class="form-control" name="order_state_id" >

                    <?php $__currentLoopData = $item_states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item_state->state_id); ?>"
                            <?php if($item_state->state_id == $order->order_state_id): ?> selected <?php endif; ?> >
                            <?php echo e($item_state->state_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('order_state_id')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('order_state_id')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('OrderController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>