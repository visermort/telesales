<?php $__env->startSection('content'); ?>


    <div class="panel-heading table-heading">Статус</div>

        <div class="panel col-sm-12 ">
            <form id="photos-form" method="post" action="<?php echo e(action('Admin\StateController@store')); ?>" >
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('state_name') ? ' has-error' : ''); ?> col-sm-6">
                    <label for="state_name">Название</label>
                    <input id="state_name" type="text" class="form-control" name="state_name" placeholder="Название" value="<?php echo e(old('state_name')); ?>" >
                    <?php if($errors->has('state_name')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('state_name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('state_slug') ? ' has-error' : ''); ?> col-sm-3">
                    <label for="state_slug">Псевдоним</label>
                    <input id="state_slug" type="text" class="form-control" name="state_slug" placeholder="Псвдоним" value="<?php echo e(old('state_slug')); ?>" >
                    <?php if($errors->has('state_slug')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('state_slug')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group buttons-horizontal col-sm-2">
                    <input class="btn btn-primary" type="submit" value="Создать статус">
                </div>
            </form>
        </div>



    <div class="panel-body datagrid">

        <table id="tt" class="easyui-datagrid" style="width:100%;height:auto;">
            <thead>
            <tr class="head">
                <th class="table-heading" nowrap width="5%">Id</th>
                <th class="table-heading" nowrap width="65%">Название</th>
                <th class="table-heading" nowrap width="25%">Псевдоним</th>
                <th class="table-heading" nowrap width="5%">Изменить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($state->state_id); ?></td>
                    <td><?php echo e($state->state_name); ?></td>
                    <td><?php echo e($state->state_slug); ?></td>
                    <td><a href="<?php echo e(action('Admin\StateController@edit', $state->state_id)); ?>"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true" ></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
    <div class="pagination">
        <?php echo e($states->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>