<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить статус
        <?php echo e($state->state_name); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('Admin\StateController@update', $state->state_id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group <?php echo e($errors->has('state_name') ? ' has-error' : ''); ?>">
                <label for="state_name">Название </label>
                <input name="state_name" id="state_name" class="form-control" value="<?php echo e($state->state_name); ?>" >

                <?php if($errors->has('state_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('state_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('state_slug') ? ' has-error' : ''); ?>">
                <label for="state_slug">Цена</label>
                <input name="state_slug" id="state_slug" class="form-control" value="<?php echo e($state->state_slug); ?>">

                <?php if($errors->has('state_slug')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('state_slug')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('Admin\StateController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>