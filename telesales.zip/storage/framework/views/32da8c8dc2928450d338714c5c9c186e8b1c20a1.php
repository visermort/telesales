<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить продукт
        <?php echo e($good->good_name); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('Admin\GoodController@update', $good->good_id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group <?php echo e($errors->has('good_name') ? ' has-error' : ''); ?>">
                <label for="good_name">Название </label>
                <input name="good_name" id="good_name" class="form-control" value="<?php echo e($good->good_name); ?>" >

                <?php if($errors->has('good_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('good_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('goog_price') ? ' has-error' : ''); ?>">
                <label for="goog_price">Цена</label>
                <input name="goog_price" id="goog_price" class="form-control" value="<?php echo e($good->goog_price); ?>">

                <?php if($errors->has('goog_price')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('goog_price')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('Admin\GoodController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>