<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить продукт
        <?php echo e($good->goods_name); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('Admin\GoodController@update', $good->goods_id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group <?php echo e($errors->has('goods_name') ? ' has-error' : ''); ?>">
                <label for="goods_name">Название </label>
                <input name="goods_name" id="goods_name" class="form-control" value="<?php echo e($good->goods_name); ?>" >

                <?php if($errors->has('goods_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('goods_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('goods_price') ? ' has-error' : ''); ?>">
                <label for="goods_price">Цена</label>
                <input name="goods_price" id="goods_price" class="form-control" value="<?php echo e($good->goods_price); ?>">

                <?php if($errors->has('goods_price')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('goods_price')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('Admin\GoodController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>