<?php $__env->startSection('content'); ?>


    <div class="panel-heading table-heading">Пользователи</div>

        <div class="panel col-sm-12 ">
            <form id="photos-form" method="post" action="<?php echo e(action('Admin\UsersController@store')); ?>" >
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?> col-sm-3">
                    <label for="first_name">Имя</label>
                    <input id="first_name" type="text" class="form-control" name="first_name" placeholder="Имя" value="<?php echo e(old('first_name')); ?>" >
                    <?php if($errors->has('first_name')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?> col-sm-3">
                    <label for="last_name">Фамилия</label>
                    <input id="last_name" type="text" class="form-control" name="last_name" placeholder="Фамилия" value="<?php echo e(old('last_name')); ?>" >
                    <?php if($errors->has('last_name')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> col-sm-3">
                    <label for="email">Email</label>
                    <input id="email" type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" >
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group buttons-horizontal col-sm-3">
                    <input class="btn btn-primary" type="submit" value="Создать пользователя">
                </div>
            </form>
        </div>



    <div class="panel-body datagrid">

        <table id="tt" class="easyui-datagrid" style="width:100%;height:auto;">
            <thead>
            <tr class="head">
                <th class="table-heading" nowrap width="5%">Id</th>
                <th class="table-heading" nowrap width="25%">Имя</th>
                <th class="table-heading" nowrap width="25%">Email</th>
                <th class="table-heading" nowrap width="25">Последний вход</th>
                <th class="table-heading" nowrap width="15%">Роли</th>
                <th class="table-heading" nowrap width="5%">Изменить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->last_login); ?> </td>
                    <td></td>
                    <td><a href="<?php echo e(action('Admin\UsersController@edit', $user->id)); ?>"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true" ></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
    <div class="pagination">
        <?php echo e($users->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>