<?php $__env->startSection('content'); ?>


    <div class="panel-heading table-heading">Услуги</div>

        <div class="panel col-sm-12 ">
            <form id="photos-form" method="post" action="<?php echo e(action('Admin\ServiceController@store')); ?>" >
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('services_name') ? ' has-error' : ''); ?> col-sm-6">
                    <label for="services_name">Название</label>
                    <input id="services_name" type="text" class="form-control" name="services_name" placeholder="Название" value="<?php echo e(old('services_name')); ?>" >
                    <?php if($errors->has('services_name')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('services_name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('services_price') ? ' has-error' : ''); ?> col-sm-3">
                    <label for="services_price">Цена</label>
                    <input id="services_price" type="text" class="form-control" name="services_price" placeholder="Цена" value="<?php echo e(old('services_price')); ?>" >
                    <?php if($errors->has('services_price')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('services_price')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group buttons-horizontal col-sm-2">
                    <input class="btn btn-primary" type="submit" value="Создать Услугу">
                </div>
            </form>
        </div>



    <div class="panel-body datagrid">

        <table id="tt" class="easyui-datagrid" style="width:100%;height:auto;">
            <thead>
            <tr class="head">
                <th class="table-heading" nowrap width="5%">Id</th>
                <th class="table-heading" nowrap width="65%">Услуга</th>
                <th class="table-heading" nowrap width="25%">Цена</th>
                <th class="table-heading" nowrap width="5%">Изменить</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($service->services_id); ?></td>
                    <td><?php echo e($service->services_name); ?></td>
                    <td><?php echo e($service->services_price); ?></td>
                    <td><a href="<?php echo e(action('Admin\ServiceController@edit', $service->services_id)); ?>"><i class="fa fa-pencil-square-o fa-2x" aria-hidden="true" ></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
    <div class="pagination">
        <?php echo e($services->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>