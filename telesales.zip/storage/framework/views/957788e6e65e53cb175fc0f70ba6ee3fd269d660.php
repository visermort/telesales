<?php $__env->startSection('content'); ?>

    <div class="panel-heading table-heading">Изменить услугу
        <?php echo e($service->services_name); ?>

    </div>
    <div class="col-sm-6 col-sm-offset-3">
        <form action="<?php echo e(action('Admin\ServiceController@update', $service->services_id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group <?php echo e($errors->has('services_name') ? ' has-error' : ''); ?>">
                <label for="services_name">Название </label>
                <input name="services_name" id="services_name" class="form-control" value="<?php echo e($service->services_name); ?>" >

                <?php if($errors->has('services_name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('services_name')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group <?php echo e($errors->has('services_price') ? ' has-error' : ''); ?>">
                <label for="services_price">Цена</label>
                <input name="services_price" id="services_price" class="form-control" value="<?php echo e($service->services_price); ?>">

                <?php if($errors->has('services_price')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('services_price')); ?></strong>
                    </span>
                <?php endif; ?>

            </div>

            <div class="form-group">
                <input class="btn btn-primary" type="submit" value="Применить">
                <a class="btn btn-primary" href="<?php echo e(action('Admin\ServiceController@index')); ?>">Отмена</a>
            </div>


        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>