<?php
return [
    /**
     * email and password for administrator
     */
    'adminEmail' => env('ADMIN_EMAIL'),

    'paginate' => 2,

    'itemTypes' => [
        'goods' => 'Продукты',
        'services' => 'Услуги',
        'additional' => 'Прочее',
    ],
    
];